## 1.2.0

- Add ethernet as connectivity result.

## 1.1.0

- Update connectivity plus

## 1.0.2

- Update connectivity plus

## 1.0.1

- Improve documentation

## 1.0.0

- Migrated to null safety

## 0.1.1

- Address pub score

## 0.1.0

- Initial release for Windows.
